/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenar;

/**
 *
 * @author lucca
 */
public class InsertionSort implements Sortable{
    public void inverter(int[] array, int a, int b) {
        int aux = array[a];
        array[a] = array[b];
        array[b] = aux;       
        
    }
    
    public String toString() {
        return "InsertionSort";
    }
    
    public void sort(int[] array) {
        int n = array.length;        
        for(int i = 1; i < n; i++) {
            int j = i;
            while(j > 0 && array[j-1] > array[j]) {
                inverter(array, j, j-1);
                j--;
            }
        } 
    }
}
